package com.bajratechnologies.nagariknews.controller.interfaces;

/**
 * Created by ronem on 5/11/16.
 */
public interface ListPositionListener {
    void tappedPosition(int position);
}
