//package com.bidhee.nagariknews.model;
//
///**
// * Created by ronem on 4/20/16.
// */
//public class NewsDetail {
//    private String newsId;
//    private String newsTitle;
//    private String newsDetail;
//    private String featuredImage;
//    private String newsUrl;
//    private String newsPublishedDate;
//    private String authorName;
//
//    public NewsDetail(String newsId, String newsTitle, String newsDetail,
//                      String featuredImage, String newsUrl,String newsPublishedDate, String authorName) {
//        this.newsId = newsId;
//        this.newsTitle = newsTitle;
//        this.newsDetail = newsDetail;
//        this.featuredImage = featuredImage;
//        this.newsUrl = newsUrl;
//        this.newsPublishedDate = newsPublishedDate;
//        this.authorName = authorName;
//    }
//
//    public String getNewsId() {
//        return newsId;
//    }
//
//    public String getNewsTitle() {
//        return newsTitle;
//    }
//
//    public String getNewsDetail() {
//        return newsDetail;
//    }
//
//    public String getFeaturedImage() {
//        return featuredImage;
//    }
//
//    public String getNewsUrl() {
//        return newsUrl;
//    }
//
//    public String getNewsPublishedDate() {
//        return newsPublishedDate;
//    }
//
//    public String getAuthorName() {
//        return authorName;
//    }
//}
