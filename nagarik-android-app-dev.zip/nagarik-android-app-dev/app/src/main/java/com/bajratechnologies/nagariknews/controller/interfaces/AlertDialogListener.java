package com.bajratechnologies.nagariknews.controller.interfaces;

/**
 * Created by ronem on 5/4/16.
 */
public interface AlertDialogListener {
    void alertPositiveButtonClicked();

    void alertNegativeButtonClicked();
}