package com.bajratechnologies.nagariknews.controller.server_request;

/**
 * Created by ronem on 4/20/16.
 */
public class RequestTask {
}
