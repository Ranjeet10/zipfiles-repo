package com.bajratechnologies.nagariknews.views.customviews;

import android.app.Dialog;
import android.content.Context;

/**
 * Created by ronem on 6/26/16.
 */
public class SeekbarDialog extends Dialog {
    public SeekbarDialog(Context context) {
        super(context);
    }
}
