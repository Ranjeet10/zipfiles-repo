package com.bajratechnologies.nagariknews.Utils;

/**
 * Created by ronem on 2/14/16.
 */
public class NewsData {
    private static String newsUrl = "http://nagariknews.com/main-story/story/65167.html";
    //    private static String img = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnqivhS7umB9iog3r5wL5k5pNZPF_jOtvEIe6dii7csdFmmPwN";
    private static String[] imgArray = new String[]{
            "http://nagariknews.com/images/2016/Holi_Ritesh/940x652xBirjung_Holi_1.JPG.pagespeed.ic.7t-il8S0AV.jpg",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnqivhS7umB9iog3r5wL5k5pNZPF_jOtvEIe6dii7csdFmmPwN",
            "ff"
    };



}
