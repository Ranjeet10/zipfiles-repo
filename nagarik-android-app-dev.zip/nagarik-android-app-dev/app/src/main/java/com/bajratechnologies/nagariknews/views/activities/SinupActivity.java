package com.bajratechnologies.nagariknews.views.activities;

/**
 * Created by ronem on 2/7/16.
 */
public class SinupActivity {
}
