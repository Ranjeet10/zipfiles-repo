package com.bajratechnologies.nagariknews.Utils;

/**
 * Created by ronem on 2/22/16.
 */
public class JSONData {
}
