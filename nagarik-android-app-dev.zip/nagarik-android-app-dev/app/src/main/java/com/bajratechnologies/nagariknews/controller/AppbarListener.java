package com.bajratechnologies.nagariknews.controller;

/**
 * Created by ronem on 3/29/16.
 */
public interface AppbarListener {
    void showAppBar(Boolean show);
}
